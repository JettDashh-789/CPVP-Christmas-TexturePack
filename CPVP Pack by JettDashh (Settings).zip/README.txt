=====================================================
  CPVP PACK by JettDashh  -  Christmas Edition (ChristmasCPVP)
  discord: hxllxw_x
=====================================================

Clean Christmas-themed crystal PvP resource pack with low fire and an FPS boost.

SUPPORTED VERSIONS
  Minecraft Java Edition 1.21 through 26.1.2 (pack formats 34 - 84, declared range 34 - 99).
  Do NOT unzip. Put the zip in .minecraft/resourcepacks and enable it.

WHAT IS IN THIS PACK
  Items:   candy-cane swords (red = netherite, green = diamond), BELL golden apples,
           Christmas tree totem, ornament end crystal, frosty ender pearl, XP bottle,
           gingerbread cookie, snowball
  Blocks:  candy-cane end crystal + obsidian, gift crafting table, gift ender chest, glowstone
  Armor:   Santa suit (netherite), elf suit (diamond)
  UI:      snow-white inventory / crafting / chest / ender chest / shulker / dispenser,
           hotbar, hearts, snowy menu backgrounds
  Menu:    dark starry sky panorama, Christmas splash texts
           (Merry Christmas! / Made by JettDashh! / Discord: hxllxw_x) and a
           "Merry Christmas! Made by JettDashh / Discord: hxllxw_x" start-up screen
  FPS:     low fire, static water and lava, tiny explosions, no big smoke

PICK AND CHOOSE (the "settings")
  Resource packs have no in-game settings screen. Instead, the ChristmasCPVP download
  splits this pack into small MODULES and OPTIONS. Enable only the ones you want and
  stack the OPTIONS above the modules (higher in the list wins).
  See README.txt in ChristmasCPVP.zip.

NOTES
  - Custom in-world skies (stars / christmas trees) need OptiFine, or Fabric with a
    skybox mod such as Skyboxify. The menu sky works in plain Minecraft.
  - Pack icon and all textures are original pixel art.

Merry Christmas and happy crystalling!
=====================================================


ALL-IN-ONE SETTINGS (this file contains every option)
  Needs the mods Respackopts + LibJF (+ Fabric API on Fabric), on Fabric or NeoForge.
  Options > Resource Packs > select this pack > click the settings button next to it.

  crystalStyle     christmas / iceBlue / purple / off
  totemStyle       tree / picture / cat / off
  goldenApples     bells / classic / off
  swordStyle       candyCane / iceCandyCane / classic / off
  armorStyle       santaAndElf / ice / off
  guiStyle         christmas / frostyBlue / evergreen / plainGrey / off
  menuSky          stars / christmasTrees / off
  inWorldSky       stars / christmasTrees / off   (needs OptiFine or a skybox mod)
  fireStyle        low / hidden / off
  on/off:          obsidian, pearlAndXpBottle, hotbarAndHearts, giftBlocks, xmasExtras,
                   menuTextAndBackgrounds, staticLiquids, tinyExplosionsAndNoSmoke,
                   minimalParticles, cloudsHidden, tntGiftBox, sunStar
  "off" = the default Minecraft look for that part.

  WITHOUT the mods: the pack loads with the default choice of every setting, and
  the on/off extras (minimal particles, hidden clouds, TNT gift, sun star) are on.
  The picture totem and cat totem are only used when selected in the settings.
