=====================================================
  CPVP PACK by JettDashh  -  Christmas Edition
  discord: hxllxw_x
=====================================================

A clean, Christmas-themed crystal PvP (CPVP) resource pack with
low fire and a small FPS boost.


SUPPORTED VERSIONS
------------------
Minecraft: Java Edition 1.21 through 26.1.2 (and newer, as long as the
pack format stays compatible).

  1.21 - 1.21.1      pack format 34
  1.21.2 - 1.21.3    pack format 42
  1.21.4             pack format 46
  1.21.5             pack format 55
  1.21.6             pack format 63
  1.21.7 - 1.21.8    pack format 64
  1.21.9 - 1.21.10   pack format 69
  1.21.11            pack format 75
  26.1 - 26.1.2      pack format 84

The pack declares the whole range 34 - 99, so it should load without
the "made for an older/newer version" warning. If your version still
shows a warning, you can safely enable the pack anyway.


INSTALL
-------
1. Do NOT unzip this file.
2. Put "CPVP Pack by JettDashh.zip" in your .minecraft/resourcepacks folder
   (or use Options > Resource Packs > Open Pack Folder).
3. Enable it in Options > Resource Packs.


FEATURES
--------
PvP items
  - End crystal: candy-cane red/white cube, gold core, green base
    (high contrast, easy to spot) + ornament inventory icon
  - Totem of Undying: Christmas tree with a gold star
  - Golden apple: gift-wrapped (red ribbon)
  - Enchanted golden apple: gift-wrapped (green ribbon, sparkles)
  - Ender pearl: frosty teal ornament
  - Bottle o' Enchanting: green bottle with red cork
  - Netherite sword: red/white candy-cane blade
  - Diamond sword: green/white candy-cane blade
  - Netherite armor: Santa suit (red, white fur, gold buckle)
  - Diamond armor: elf suit (green, white fur, gold buckle)

Blocks
  - Obsidian: deep dark crystal look with snow specks and clear edges
  - Crafting table: gift-wrapped block with gold ribbon
  - Ender chest: green present chest with red ribbon and gold latch
  - Glowstone: golden, with snow specks

Interface
  - Inventory, crafting table, chest/ender chest/barrel, shulker box
    and dispenser screens: snow-white panels with a red border
  - Hotbar with gold selection box
  - Hearts (normal, half, blinking, absorption)

Performance / FPS
  - Low fire (short flames at the bottom of the screen)
  - Static (non-animated) water and lava
  - Much smaller explosion particles
  - Big smoke particles removed
  (These give a small FPS gain, mostly during crystal fights.)


NOTES
-----
- Pack icon and all textures are original pixel art made for this pack.
- Other screens (furnace, anvil, etc.) and other items keep the
  default look.
- Bug reports and requests: discord hxllxw_x

Enjoy and merry crystalling!
=====================================================
